import collections,json,re
from pathlib import Path
root=Path('.local/tencent-capacity-20260928')
pattern=re.compile(r'^(\d+\.\d+) IP (\d+\.\d+\.\d+\.\d+)\.(\d+) > (\d+\.\d+\.\d+\.\d+)\.(\d+): Flags \[(S\.?)\], seq (\d+)(?:, ack (\d+))?')
def load(path,server):
 rows=[]
 for l in path.read_text().splitlines():
  m=pattern.search(l)
  if not m:continue
  ts,src,sp,dst,dp,flag,seq,ack=m.groups()
  if flag=='S' and dp=='443':rows.append({'at':float(ts),'kind':'syn','isn':int(seq),'source_port':int(sp)})
  if flag=='S.' and sp=='443' and ack:rows.append({'at':float(ts),'kind':'synack','isn':(int(ack)-1)%2**32,'source_port':int(dp)})
 return rows
client=load(root/'syn-client.txt',False);server=load(root/'syn-server.txt',True)
phase=json.loads((root/'phase-window.json').read_text())
result={}
for name,window in phase.items():
 start,end=window
 c=[r for r in client if start-1<=r['at']<=end+1];s=[r for r in server if start-1<=r['at']<=end+1]
 cs={r['isn'] for r in c if r['kind']=='syn'};ss={r['isn'] for r in s if r['kind']=='syn'};sa={r['isn'] for r in s if r['kind']=='synack'};ca={r['isn'] for r in c if r['kind']=='synack'}
 def first(rows,kind):
  d={}
  for r in rows:
   if r['kind']==kind:d[r['isn']]=min(d.get(r['isn'],r['at']),r['at'])
  return d
 cf=first(c,'syn');sf=first(s,'syn');sa_first=first(s,'synack');ca_first=first(c,'synack')
 def stats(v):
  v=sorted(v);return {'count':len(v),'p50_s':v[len(v)//2] if v else None,'p95_s':v[min(len(v)-1,int(len(v)*.95))] if v else None,'over_200ms':sum(x>.2 for x in v)}
 outbound=stats([sf[k]-cf[k] for k in cs&ss]);inbound=stats([ca_first[k]-sa_first[k] for k in cs&sa&ca])
 result[name]={'first_syn_client_to_server':outbound,'first_synack_server_to_client':inbound,'client_unique_syn':len(cs),'server_received_client_syn':len(cs&ss),'client_syn_missing_at_server':len(cs-ss),'server_replied_to_client_syn':len(cs&sa),'client_received_server_synack':len(cs&ca),'server_synack_missing_at_client':len((cs&sa)-ca),'client_packets':dict(collections.Counter(r['kind'] for r in c)),'server_packets':dict(collections.Counter(r['kind'] for r in s))}
Path('reports/tencent-capacity-20260928/handshake-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
