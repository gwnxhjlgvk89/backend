import collections,json,hashlib,statistics
from pathlib import Path
root=Path('reports/tencent-capacity-20260928')
rows=[]
for name in ('cold-1','cold-2','cold-3','ready-600','hot','last-seat'):
 p=root/(name+'.json')
 if not p.exists():continue
 d=json.loads(p.read_text());r=d['runs'][0];s=r['stages'];en=s['enroll'];login=s.get('login',{})
 rows.append({'case':name,'completed':r['completed_students'],'enrollments':r['db']['enrollments'],'data_consistent':r['data_consistency_pass'],'outcomes':r['outcomes'],'login':login,'enrollment':en,'websocket':r['websocket'],'steady_reads':r['steady_reads_after_20s'],'gates':r['scope_gates'],'active_seconds':r['active_duration_s'],'epoch':r['measured_epoch']})
(root/'summary.json').write_text(json.dumps({'cases':rows,'capacity_pass':False,'application_commit':'81adef2bfa4441fc54d014f445e1f81383242a13','test_driver_commit':'2766808','scope':'actual Tencent 4 vCPU / approximately 4GB and public HTTPS; isolated synthetic database'},indent=2)+'\n')
for r in rows:print(r['case'],r['completed'],r['enrollments'],r['login'].get('p95_s'),r['enrollment']['p95_s'],r['enrollment']['p99_s'],r['websocket']['open_at_end'])
monitor=root/'process-health.jsonl'
if monitor.exists():
 ss=[json.loads(line) for line in monitor.read_text().splitlines()];valid=[s for s in ss if 'services' in s]
 result={'sample_count':len(ss),'sample_errors':len(ss)-len(valid),'span_s':valid[-1]['at']-valid[0]['at'],'services':{},'health_statuses':dict(collections.Counter(str(h.get('status',h.get('error'))) for s in valid for h in s['health'].values()))}
 def counters(text):
  lines=text.splitlines();d={}
  for a,b in zip(lines[::2],lines[1::2]):
   aa=a.split();bb=b.split();d.update({aa[0]+k:int(v) for k,v in zip(aa[1:],bb[1:])})
  return d
 def proc_events(r):return dict((k,int(v)) for k,v in (line.split() for line in r['resources']['memory.events'].splitlines()))
 def usage(r):return int(dict(line.split() for line in r['resources']['cpu.stat'].splitlines())['usage_usec'])
 for name in valid[0]['services']:
  rr=[s['services'][name] for s in valid];base=rr[0];peak=max(int(r['resources']['memory.current']) for r in rr)/1048576
  result['services'][name]={'processes_unchanged':all(r['processes']==base['processes'] for r in rr),'restarts_max':max(int(r.get('NRestarts','0')) for r in rr),'memory_peak_mib':round(peak,1),'memory_start_mib':round(int(base['resources']['memory.current'])/1048576,1),'memory_end_mib':round(int(rr[-1]['resources']['memory.current'])/1048576,1),'oom_kill_delta':proc_events(rr[-1]).get('oom_kill',0)-proc_events(base).get('oom_kill',0)}
 cpu=[];net=[]
 def sent(s):return sum(int(line.split(':')[1].split()[8]) for line in s['net_dev'].splitlines() if ':' in line and not line.lstrip().startswith('lo:'))
 for a,b in zip(valid,valid[1:]):
  dt=b['at']-a['at'];cpu.append(sum(usage(b['services'][k])-usage(a['services'][k]) for k in a['services'])/dt/1e6);net.append((sent(b)-sent(a))*8/dt/1e6)
 result['services_cpu_cores_sample_max']=max(cpu);result['egress_mbps_sample_max']=max(net)
 result['host_oom_delta']=valid[-1]['host_oom_kills']-valid[0]['host_oom_kills']
 result['available_memory_mib_min']=min(int(s['host_memory']['MemAvailable'].split()[0])/1024 for s in valid)
 result['swap_used_mib_max']=max((int(s['host_memory']['SwapTotal'].split()[0])-int(s['host_memory']['SwapFree'].split()[0]))/1024 for s in valid)
 result['outbox_pending_max']=max(s.get('dependencies',{}).get('club_outbox_pending',0) for s in valid)
 result['network_counter_deltas']={}
 for field in ('snmp','netstat'):
  a=counters(valid[0][field]);b=counters(valid[-1][field])
  result['network_counter_deltas'].update({k:b[k]-v for k,v in a.items() if any(w in k for w in ('RetransSegs','ListenOverflows','ListenDrops','TCPTimeouts','TCPSynRetrans','TCPBacklogDrop'))})
 (root/'resource-summary.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
