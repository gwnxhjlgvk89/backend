import json,subprocess,time,sys
N=4194304
cmd=['ssh','-S',sys.argv[1],'-o','BatchMode=yes','ubuntu@150.158.22.139',f'head -c {N} /dev/urandom']
start=time.monotonic();r=subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=45);elapsed=time.monotonic()-start
print(json.dumps({'origin':sys.argv[2],'bytes':N,'seconds':elapsed,'mbps':N*8/elapsed/1e6,'exit_code':r.returncode,'payload':'synthetic incompressible bytes, discarded'}))
assert r.returncode==0
