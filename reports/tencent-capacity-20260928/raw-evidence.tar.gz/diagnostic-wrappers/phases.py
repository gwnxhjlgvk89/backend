"""Bounded TCP/TLS/HTTP comparison after the full workflow load has ended."""
import json,subprocess,sys,time
from pathlib import Path
from scripts import load_connection_phases as phase
root=Path('reports/phases');root.mkdir(exist_ok=False)
results={};windows={}
for mode in ('tls','health','login','tunnel_health'):
 epoch=time.time()+5;children=[]
 for shard in range(3):
  output=root/f'{mode}-{shard}.json'
  code="""import asyncio
from types import SimpleNamespace
from scripts import load_connection_phases as p
p.TARGET='wjy-1214.cloud';p.PORT=443;p.DIAL=DIAL_VALUE
a=SimpleNamespace(mode=MODE,users=500,offset=OFFSET,timeout=10,epoch=EPOCH,burst=0.6,ca='/etc/ssl/certs/ca-certificates.crt',report=REPORT)
asyncio.run(p.main(a))""".replace('DIAL_VALUE',repr(('127.0.0.1',18443) if mode=='tunnel_health' else ('150.158.22.139',443))).replace('MODE',repr('health' if mode=='tunnel_health' else mode)).replace('OFFSET',str(shard*500)).replace('EPOCH',repr(epoch)).replace('REPORT',repr(str(output)))
  children.append(subprocess.Popen([sys.executable,'-c',code],stdout=subprocess.DEVNULL))
 assert all(p.wait()==0 for p in children)
 rows=[r for shard in range(3) for r in json.loads((root/f'{mode}-{shard}.json').read_text())['rows']]
 windows[mode]=[epoch,time.time()];(root/'windows.json').write_text(json.dumps(windows));results[mode]=phase.summarize(rows);print(mode,json.dumps(results[mode]),flush=True)
 time.sleep(5)
(root/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
